# News_App-
A simple news application created in android studio using news.org api 



Features:-


1.Good UI


2.News Share Intent


3.Search Bar


4.Swipe to Refresh Layout


5.Used Retrofit Networking


To View Sample Screenshots [Click Here](https://drive.google.com/folderview?id=141IFp1SI3oqXX0apPFn7oyUC1NqnHqXi)

To install the Apk [Click Here](https://drive.google.com/open?id=128HJQ62j3rvQtNuIzN0Mh1mBu8Y4I9hi)
